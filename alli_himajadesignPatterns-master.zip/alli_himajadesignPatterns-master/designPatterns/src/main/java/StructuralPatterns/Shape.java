package StructuralPatterns;

public interface Shape {
	public void draw(String fillColor);

}
